<section id="advertisement">
		<div class="container">
			<img src="<?php echo base_url()?>assets/front/images/shop/advertisement.jpg" alt="" />
		</div>
	</section>
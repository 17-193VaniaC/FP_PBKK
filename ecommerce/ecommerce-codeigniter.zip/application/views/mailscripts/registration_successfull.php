<h2>Hello, <?php echo $name?></h2><hr/>
<h3>Thanks to join our community</h3>
<h3>Your Login Information..........</h3>
<span>Email:<b><?php echo $to;?></b></span><br/>
<span>Password:<b><?php echo $password;?></b></span>